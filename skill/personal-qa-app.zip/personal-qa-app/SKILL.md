---
name: 个人问答应用
description: 基于个人 Obsidian 知识库构建三端（浏览器/Windows EXE/安卓 APK）AI 问答应用的全流程技能。当用户需要"把 Obsidian 笔记做成聊天机器人"、"知识库问答"、"个人 RAG 应用"、"知识库聊天助手"、"部署知识库服务到云端"、"PC/安卓问答客户端"、"知识库索引同步/自动更新"时使用。本技能涵盖：FastAPI RAG 服务端（本地嵌入+DeepSeek）、Windows pywebview 客户端、安卓 WebView 客户端、腾讯云 CloudBase 云托管部署、索引热更新与自动同步，以及全套踩坑修复方案（WebView2 降级、PyInstaller safe-delete、Gradle 中文路径、云构建 pip 镜像 403 等）。
agent_created: true
---

# 个人问答应用（Obsidian 知识库三端 AI 问答助手）

## 概述

把用户的 **Obsidian 个人知识库**（vault）变成可对话的 AI 助手：本地向量化笔记 → 检索相关片段 → 交给 DeepSeek 生成带来源的回答。支持浏览器 / Windows EXE / 安卓 APK 三端，可部署到公网供好友使用。

**核心原则**：笔记向量化完全在本地（fastembed + ONNX），隐私友好；只有提问时把"问题+命中的片段"发给云端 LLM。

## 触发场景

- 用户要把 Obsidian/本地笔记库做成问答机器人
- 用户需要"个人 RAG 应用"、"知识库聊天助手"
- 用户要打包 Windows EXE / 安卓 APK 客户端
- 用户要部署知识库服务到云端（Docker / 腾讯云 CloudBase）
- 用户反馈"新文档查不到" → 索引快照问题（见下方索引同步机制）

## 架构决策

```
Obsidian vault (本地 VAULT_PATH)
   │ build_index.py：遍历 md → 分块(按标题+滑动窗口) → 本地向量化
   ▼
kb.db (sqlite: chunks 表含 embedding BLOB + meta 表)
   │ retrieve.py：mtime 热重载缓存 → 余弦检索 Top-K → MIN_SCORE 过滤
   ▼
app.py (FastAPI)：/ (聊天UI) /api/chat(SSE流式) /api/note /api/health
   │ /api/admin/db(上传索引) /api/admin/stats(索引状态)
   ▼
DeepSeek API（仅发问题+片段）
```

- **瘦客户端**：PC(EXE)/安卓(APK) 只负责连服务器显示 UI，本地不跑模型、不持密钥
- **鉴权**：SERVER_TOKEN（`?token=` / `Authorization: Bearer` / Cookie）+ 按 IP 限流
- **检索质量**：查询改写（DeepSeek 补关键词）→ 余弦相似度 → `MIN_SCORE=0.49` 砍噪声（bge-small-zh-v1.5 经验分布：强相关 ≥0.55、弱相关 0.45-0.55、无关 <0.45）

## 实现步骤

### 1. 服务端（核心）

1. 建 `config.py`：从 `.env` 读 `DEEPSEEK_API_KEY` / `SERVER_TOKEN` / `VAULT_PATH` / `EXCLUDE_DIRS` / `EMBEDDING_MODEL` / `CHUNK_SIZE` / `TOP_K` / `MIN_SCORE`；启动时设 `HF_ENDPOINT=https://hf-mirror.com` + `HF_HUB_DISABLE_XET=1`
2. `build_index.py`：遍历 vault（排除 `.obsidian,.copilot,copilot,.agents,.claude,.opencode,.trash`）→ 去 frontmatter、解 wikilink → 按标题分块（超长滑动窗口 CHUNK_SIZE=700/OVERLAP=120）→ `embed.embed_texts()` 批量向量化 → 写 sqlite
3. `retrieve.py`：**mtime 热重载**（`_cache={"data":None,"mtime":0}`，文件变了自动重载）→ 归一化余弦检索 → 按 score 降序、跌破 MIN_SCORE 停止
4. `app.py`：FastAPI + CORS；`/api/chat` 先 `_expand_query()`（DeepSeek 改写关键词）再检索，SSE 流式返回（先 `sources` 事件再 `delta` 再 `done`）
5. **索引管理接口（必须加）**：`POST /api/admin/db`（收 kb.db 字节 → 临时文件 → `os.replace` 原子替换 → `retrieve.reload()`）+ `GET /api/admin/stats`——这是"知识库更新"闭环的关键

### 2. Windows 客户端（pywebview）

- `client_pc.py`：首次打开填服务器地址+令牌 → 存 `%APPDATA%\KBChat\config.json` → `load_url(地址?token=)`
- **⚠️ WebView2 必坑**：pywebview 6.x 在 Windows 只认 EdgeUpdate 注册表里的 WebView2 Runtime；很多机器 Edge 装了但 WebView2 未单独注册 → pywebview 静默降级 IE(MSHTML)，**界面能渲染但 JS 桥全断（按钮无反应、config.json 不写）**。解法：启动时 `webview.settings["WEBVIEW2_RUNTIME_PATH"]` 指向探测到的 `EdgeCore/<版本>/` 或 `EdgeWebView/Application/<版本>/`（见 references/pitfalls.md）
- 打包：PyInstaller `--onedir`（勿用 --onefile，bootloader 残留挂起）+ `--hidden-import webview.platforms.edgechromium --collect-submodules webview pythonnet`；Inno Setup `PrivilegesRequired=lowest` 免管理员

### 3. 安卓客户端（WebView shell）

- `MainActivity.java`：WebView 开 JS+DOM+`MIXED_CONTENT_ALWAYS_ALLOW`；设置对话框持久化 url/token 到 SharedPreferences；加载 `服务器地址?token=`
- Manifest：`INTERNET` + `usesCleartextTraffic=true` + launcher activity
- **⚠️ Gradle 中文路径必坑**：项目路径含中文（如"工作"）时 Java 按 GBK 误解析 → `.gradle` 缓存锁创建报"拒绝访问"。**解法：复制工程到纯 ASCII 路径构建**（如 `C:\Users\xxx\.workbuddy\logs\apk_build\`），再复制 APK 回来
- 图标用自定义 mipmap（勿用 `@android:drawable/ic_menu_manage` 默认图标——用户会认不出）；交付文件名带应用名（如 `KBChat-知识库助手-v1.1.apk`）防传错

### 4. 云端部署（腾讯云 CloudBase 云托管，实测路线）

1. 开通云托管环境（`CreateCloudRunEnv`，EnvType=baas）→ 创建容器服务（PUBLIC、Cpu1/Mem2/Min1/Max5/Port8000、EnvParams 注入 DEEPSEEK_API_KEY + SERVER_TOKEN）
2. **镜像构建坑**：腾讯云构建机访问 pypi tuna 镜像 403 → Dockerfile 用 `-i https://mirrors.tencent.com/pypi/simple/ --extra-index-url https://pypi.org/simple`
3. **模型预下载**：Dockerfile 构建期 `RUN python -c "from fastembed import TextEmbedding; TextEmbedding(model_name='BAAI/bge-small-zh-v1.5')"` 烘焙模型到镜像（`HF_HOME=/app/.cache/huggingface`），避免运行期冷启动联网
4. 容器必须监听平台注入的 `PORT`（`uvicorn --port ${PORT:-8000}`）
5. MCP 部署要求 targetPath 在 MCP 运行时 cwd 内（沙箱写 MCP 目录需 dangerouslyDisableSandbox）
6. 部署后验证：`/api/health`=200、`/api/chat` 无 token=401、`/?token=` 返回 UI、带 token 实测问答流

### 5. 知识库更新机制（用户"新文档查不到"的根因与解法）

- **根因**：kb.db 是构建期快照——镜像/部署时索引定死，之后 vault 新增文档永远检索不到
- **解法**：retrieve 的 mtime 热重载 + `POST /api/admin/db` 上传接口 = 替换文件即生效，无需重启
- 本地同步：`sync_index.py`（重建 build → POST 上传 → 查 stats）；Windows 双击 bat
- 自动同步（推荐）：`vault_watch.py` 常驻轮询 vault 文件 mtime 快照（3s 间隔），变化且稳定 15s 后自动重建+上传；`--install` 注册 HKCU Run 开机自启（免管理员）

## 关键文件清单

| 文件 | 作用 |
|---|---|
| config.py | 配置读取 + HF 镜像设置 |
| build_index.py | 遍历 vault → 分块 → 向量化 → kb.db |
| retrieve.py | mtime 热重载检索 |
| app.py | FastAPI 路由 + 管理接口 |
| client_pc.py | Windows 客户端（含 WebView2 探测） |
| android-client/ | 安卓 WebView 客户端 |
| sync_index.py / vault_watch.py | 索引同步（手动/自动） |
| Dockerfile | 云托管容器（腾讯镜像 + 模型预下载） |

## 验证清单

- [ ] 本地：`build_index.py` 提示"索引完成 N 个片段"且新文档入索引（sqlite 查 rel_path）
- [ ] 本地：`/api/chat` 带 token 流式回答、命中来源正确
- [ ] 上传索引：`POST /api/admin/db` 返回 chunks 数，stats 的 mtime 更新
- [ ] 云端：health 200 / 无 token 401 / 真实问答命中
- [ ] PC 客户端：按钮点击后 config.json 生成（WebView2 桥通）
- [ ] 安卓：aapt 验证包名/label/图标；真机安装填地址可对话

## 参考文档

- `references/pitfalls.md`：全部踩坑记录与修复（WebView2 / PyInstaller safe-delete / Gradle 中文路径 / aapt 中文路径 / 云构建 403 / Inno Setup 文件锁）
- 完整开源代码见 GitHub 仓库（含 README、Dockerfile、客户端工程）
