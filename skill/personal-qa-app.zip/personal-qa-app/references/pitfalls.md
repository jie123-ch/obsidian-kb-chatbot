# 踩坑记录与修复方案（实测）

本项目开发全程实测的坑与修法，按严重度排序。

## 1. pywebview Windows 降级 MSHTML（最坑，界面正常但全功能失效）

**症状**：pywebview 窗口能渲染 HTML、输入框能填，但点按钮毫无反应、Python 侧不执行（如 config.json 不写入）。JS 桥接层完全断裂。

**根因**：pywebview 6.2.1 在 Windows 用 `winforms.py:_is_chromium()` 决定后端，**只检查 EdgeUpdate 注册表的 "WebView2 Runtime" 键**。很多机器 Edge 浏览器装了，但 WebView2 Runtime 未单独注册（Edge 自带的 `msedgewebview2.exe` 藏在 `C:\Program Files (x86)\Microsoft\EdgeCore\<版本>\`），pywebview 检不到 → 降级 MSHTML(IE11) → IE 没有 `window.chrome.webview.postMessage` 桥 → JS 调 Python 全断。

**修复**：启动时探测 EdgeCore / EdgeWebView\Application 下版本目录（取最大版本），设置：
```python
import webview
webview.settings["WEBVIEW2_RUNTIME_PATH"] = r"C:\Program Files (x86)\Microsoft\EdgeCore\151.0.4129.59"
```
`_is_chromium()` 看到该设置**直接返回 True**，pywebview 切 edgechromium 后端，桥立即恢复。必须在本机定位 msedgewebview2.exe 所在**目录**（BrowserExecutableFolder 语义）。

**探测逻辑**：扫描 `C:\Program Files (x86)\Microsoft\EdgeCore`、`C:\Program Files\Microsoft\EdgeCore`、`EdgeWebView\Application` 下的目录，找含 `msedgewebview2.exe` 的版本目录，按版本号数字排序取最大。

## 2. PyInstaller 被 safe-delete 拦（os.remove base_library.zip OSError）

**症状**：`PyInstaller ... --onedir` 在 assemble 阶段 `os.remove(base_library.zip)` 抛 OSError（本环境 sitecustomize 注入 safe-delete，回收站不可用即 fail-closed）。

**修复**：`python -S -m PyInstaller ...` + `PYTHONPATH` 补回 site-packages：
```bash
env PYTHONPATH="C:\...\Lib\site-packages;C:\...\Lib" python.exe -S -m PyInstaller --onedir -y --name App ...
```
- `-S` 跳过 sitecustomize（safe-delete 注入点）
- PYTHONPATH 用 **Windows 路径 + 分号**（Git Bash 下 `/c/` POSIX 路径会被拼成 `C:\c\` 乱码；`;` 在 bash 单引号内安全）
- `-y` 覆盖已有 dist（否则 "output directory is not empty"）
- PyInstaller 6.17 在 venv；模块找不到时先 `pip install pyinstaller==6.17`

## 3. Gradle 中文路径构建必挂（Java GBK 误解析）

**症状**：项目路径含中文（`workbuddy工作`）→ Gradle 日志出现乱码（`workbuddy¹¤×÷`）→ `.gradle\8.13\fileHashes\fileHashes.lock` 创建报"拒绝访问" → `Could not create service of type FileHasher`。

**修复**：把工程复制到**纯 ASCII 路径**构建（如 `C:\Users\xxx\.workbuddy\logs\apk_build\`），排除 `build/ .gradle/`，构建成功再复制 APK 回原目录。GRADLE_USER_HOME 复用已有缓存目录可加速。

## 4. aapt 处理中文路径报 "Illegal byte sequence"

**症状**：`aapt dump badging "中文路径\app.apk"` 返回 `ziparchive W ... Illegal byte sequence`，badging 无输出。

**修复**：先把 APK 复制到 ASCII 临时路径再 dump；stdout 按 **GBK** 解码（Windows 控制台编码），否则 list index out of range。

## 5. 腾讯云构建机 pip 镜像 403

**症状**：云托管镜像构建 `pip install -i https://pypi.tuna.tsinghua.edu.cn/simple` 返回 `HTTP error 403`。

**修复**：改用腾讯云内网镜像并保留官方源兜底：
```dockerfile
RUN pip install --no-cache-dir -r requirements.txt \
    -i https://mirrors.tencent.com/pypi/simple/ \
    --extra-index-url https://pypi.org/simple
```

## 6. 容器健康检查失败：只监听 8000 不监听平台 PORT

**症状**：云托管 pod 一直"等待就绪"，健康检查不过。

**修复**：`CMD ["sh","-c","uvicorn app:app --host 0.0.0.0 --port ${PORT:-8000}"]`，容器必须监听平台注入的 PORT。

## 7. Inno Setup 安装报 "DeleteFile failed; code 5 拒绝访问"

**症状**：安装器升级覆盖旧 EXE 时删除失败（本机 Windows Defender 实时扫描锁住目标 exe，无管理员无法暂停）。

**修复**：重装前先结束运行中的旧程序（任务管理器）；或改 DefaultDirName + AppId 装到新目录绕过锁。PrivilegesRequired=lowest 免管理员。

## 8. 安卓模拟器在本沙箱跑不了（环境限制）

**实测**：AEHD 加速模式在 "AEHD is operational" 后进程静默消失；TCG 软模拟 qemu 进程 CPU=0 被挂起。本环境无法运行 Android 模拟器，APK 只能静态验证（aapt）+ 用户真机确认。不要浪费时间尝试多组合参数。

## 9. 后台长任务被环境回收

`run_in_background` 的任务在 turn 结束后会被清理（task not found）；长驻进程（模拟器/服务）用 PowerShell `Start-Process` 脱离进程树才能存活。Windows 下 `os.kill(pid,9)` 可能报 WinError 87，用 ctypes `TerminateProcess` 或 `taskkill`。

## 10. 知识库索引是快照（用户"新文档查不到"）

**根因**：kb.db 构建期定死（镜像/部署时），之后 vault 新增文档永远不会被检索到——不是"没有自动更新功能"，而是**缺少把新索引送到云端的通路**。

**修复**：retrieve 已有 mtime 热重载 → 加 `POST /api/admin/db`（原子替换 + reload）+ 本地 `sync_index.py` / `vault_watch.py`（自动）。用户在 Obsidian 编辑时电脑必然开机，本地 watcher 即可覆盖全部更新场景。
